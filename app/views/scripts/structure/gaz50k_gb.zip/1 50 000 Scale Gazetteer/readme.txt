	   Notes on the Supply of Ordnance Survey Digital Data
	   ---------------------------------------------------

   Directory Structure 
   -------------------

   The directory structure is shown below:

				     ROOT 
				       |
				 ------------
				|            |          
			      Data          Doc

   The ROOT directory will contain the following ASCII text file:
	  o This file - README.TXT.

   The Data directory will contain the data file.

   The Doc directory will contain the following ASCII text and pdf files:
	  
	  o LICENCE.txt - important licensing information 

          o 50K_Gazetteer_Tech_Spec.pdf - Technical specification
          
	  
   The Doc directory may also contain files specifically relating
	  to the current version of the product.
	